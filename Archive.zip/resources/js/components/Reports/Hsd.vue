<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-12">

                    <div class="card" >
                        <div class="card-header">
                            <h3 class="card-title">HSD Report</h3>
                            <div class="card-tools">
                                <button class="btn btn-sm btn-primary" @click="download"><i
                                    class="fa fa-download mr-2" aria-hidden="true"></i> Download Excel</button>
                                <button class="btn btn-sm btn-blue" @click="openSideModal"><i
                                    class="fa fa-sliders-h mr-2" aria-hidden="true"></i> Filter</button>
                            </div>
                        </div>

                        <SidebarModal ref="sidebarModal">
                            <!-- Content of the sidebar modal goes here -->
                            <h3><i class="fa fa-sliders-h mr-2" aria-hidden="true" style="font-size: 22px;"></i> Filter
                            </h3>
                            <hr>
                            <form autocomplete="off" @submit.prevent="getResults()">

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">FAR No</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :get-option-label="getLabel"
                                            :reduce="(option) => option.id" :options="search_machines"
                                            placeholder="Enter machines ..." v-model="search.machine_id"
                                            name="machine_id">
                                        </v-select>
                                    </div>
                                </div>

                                <!-- <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Select Site</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="site_name" :reduce="(option) => option.id"
                                            :options="search_sites" placeholder="Select Site..."
                                            v-model="search.site_id" name="site_id">
                                        </v-select>
                                    </div>
                                </div> -->

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">From Date</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.start_at" input-class="form-control" placeholder="Date" />
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">To Date</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.end_at" input-class="form-control" placeholder="Date" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6 mb-2 pr-1">
                                        <button type="submit" class="btn btn-success btn-block">Search</button>
                                    </div>
                                    <div class="col-6 mb-2 pl-1">
                                        <button type="button" class="btn btn-danger btn-block"
                                            @click="reset_filter()">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </SidebarModal>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0 ticketTable">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th class="stickey d-none">Action</th>
                                        <th >Current Site</th>
                                        <th>FAR No</th>
                                        <th>Name</th>
                                        <th>Model</th>
                                        <th>Actual Ave. Consumption (Ltrs/Hr)</th>
                                        <th>Actual Ave. Consumption (Kms/Ltr)</th>
                                        <th>Standard Consumption (Ltrs/Hr)</th>
                                        <th>Standard Consumption (Kms/Ltr)</th>
                                        <th>% of Actual Ave. Consumption (Ltrs/Hr)</th>
                                        <th>% of Actual Ave. Consumption (Kms/Ltr)</th>
                                        <th>Status</th>
                                        <th>Machine running status (Breakdown/Running/Idle)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(d, index)  in MainData.data" :key="index">
                                        <td class="d-none"></td>
                                        <td class="pb-2">{{ d.current_site?d.current_site.site_name:"" }}</td>
                                        <td >{{ d.far_no }}</td>
                                        <td >{{ d.name }}</td>
                                        <td >{{ d.machine_model.name }}</td>
                                        <td >{{ d.actual_avg_consumtion_ltr_hr?d.actual_avg_consumtion_ltr_hr:0 }}</td>
                                        <td >{{ d.actual_avg_consumtion_kms_hr?d.actual_avg_consumtion_kms_hr:0 }}</td>
                                        <td >{{ d.standard_consumption_hr_per_ltr?d.standard_consumption_hr_per_ltr:0 }}</td>
                                        <td >{{ d.standard_consumption_hr_per_ltr?d.standard_consumption_km_per_ltr:0 }}</td>
                                        <td >{{ d.percent_actual_avg_consumption_ltr_hr?d.percent_actual_avg_consumption_ltr_hr :0 }} %</td>
                                        <td >{{ d.percent_actual_avg_consumption_km_hr?d.percent_actual_avg_consumption_km_hr:0}} %</td>
                                        <td >{{ d.ok_status?d.ok_status:"" }}</td>
                                        <td >{{ d.condition_of_machine?d.condition_of_machine:"" }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <pagination :data="MainData" :limit="10" @pagination-change-page="getResults" v-if="MainData"></pagination>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import MultiRangeSlider from "multi-range-slider-vue";
import "multi-range-slider-vue/MultiRangeSliderBlack.css";
import "multi-range-slider-vue/MultiRangeSliderBarOnly.css";
import SidebarModal from './../SideBarModal.vue';

import VueTagsInput from '@johmun/vue-tags-input';
export default {
    components: {
        VueTagsInput,
        MultiRangeSlider,SidebarModal,
        MachinePop: () => import('../MachineFarPop.vue'),
    },
    data() {
        return {
            pmModalData:'',
            created_users: [],
            search_machines: [],
            search_sites: [],
            search: {
                page: 1,
                machine_id: '',
                site_id: '',
                start_at: '',
                end_at: '',
            },
            categories: [],
            sub_categories: [],
            sites: [],
            selected_machine: '',
            users: [],
            machines: [],
            MainData: {},


            json_fields: {
                'Ticket no': 'ticket_no',
                'Last Name': 'last_name',
                'Email': 'email',
                'Type': 'type',
                'Country Code': 'country_code',
                'Phone Number': 'phone_number',
                'VSD ID': 'vsd_id',
                'License Number': 'license_number',
            },
            json_meta: [
                [{
                    key: "charset",
                    value: "utf-8",
                },],
            ],

        }
    },
    methods: {
        download(){
            let cloaderd = this.$loading.show({
                container: this.$refs.ref_load_user
            });
            this.search.page = "";
            this.search.export = "export";
            axios({
                url: '/api/get_hsd_data',
                method: 'GET',
                responseType: 'blob', // Important
                params: this.search
            }).then(response => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'hsd_readings.xlsx'); // Set the file name
                document.body.appendChild(link);
                link.click();
                cloaderd.hide();
            }).catch(error => {
                console.error("There was an error downloading the file:", error);
                cloaderd.hide();
            });
        },
        openSideModal() {
            this.$refs.sidebarModal.openSideModal();
        },
        closeSideModal() {
            this.$refs.sidebarModal.closeSideModal();
        },
        view_site_details(data) {
            this.pmModalData = data
            $('#MachineSiteModal2').modal('show');
        },
        reset_filter(){
            this.search= {
                page: 1,
                machine_id: '',
                site_id: '',
                start_at: '',
                end_at: '',
            }
            this.getResults()
        },
        UpdateValues(e) {
            this.search.tat_from = e.minValue;
            this.search.tat_to = e.maxValue;
        },


        getLabel(val) {
            if (typeof val === 'object') {
                return val.far_no + ' - ' + val.name;
            } else {
                return val;
            }
        },
        getResults(page = 1) {

            let cloaderd = this.$loading.show();
            axios.get('api/get_hsd_data', {
                params: {
                    page: page,
                    search:this.search
                }
            }).then(({ data }) => {
                this.MainData = data.data
                cloaderd.hide();
            });
        },
        loadData() {
            let cloaderd = this.$loading.show();
            axios.get("/api/get_hsd_data", {
                params: this.search
            }).then(({
                data
            }) => {
                this.MainData = data.data;
                cloaderd.hide();
            });
        },

    },
    created() {
        this.loadData();
    },
    beforeCreate() {
        axios.get("/api/initial_ticket").then(response => {
            this.users = response.data.data.vendors;
            this.machines = response.data.data.machines;
            this.search_machines = response.data.data.machines;
            this.search_sites = response.data.data.sites;
            this.created_users = response.data.data.created_users;
        }).catch(() => console.warn('Oh. Something went wrong'));
    },
    watch: {
        async 'form.sub_category_id'(n, o) {
            if (n) {
                this.get_machine()
            }
        },
        async 'form.site_id'(n, o) {
            if (n) {
                this.get_machine()
            }
        },

        'form.category_id': {
            handler: function (n, o) {

                if (n) {
                    axios.get("api/category/" + n)
                        .then((res) => {
                            this.sub_categories = res.data.data;
                        })
                    this.get_machine()
                }
            },
            deep: true,
            initial: true
        },

    },
}
</script>
<style>
.bg-red {
  background-color: #ef5563 !important;
}
.bg-green {
  background-color: #70ed70 !important;
}
.bg-yellow {
  background-color: #f1c84c !important;
}
</style>
