<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Site Wise Expenses Report</h3>
                            <div class="card-tools">
                                <button class="btn btn-sm btn-blue" @click="openSideModal"><i
                                        class="fa fa-sliders-h mr-2" aria-hidden="true"></i> Filter</button>
                            </div>
                        </div>

                        <SidebarModal ref="sidebarModal">
                            <!-- Content of the sidebar modal goes here -->
                            <h3><i class="fa fa-sliders-h mr-2" aria-hidden="true" style="font-size: 22px;"></i> Filter
                            </h3>
                            <hr>
                            <form autocomplete="off" @submit.prevent="getResults()">

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Date From</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.date_from"
                                            input-class="form-control" placeholder="Created from date" />
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Date To</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.date_to"
                                            input-class="form-control" placeholder="Created to date" />
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">FAR No</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :get-option-label="getLabel"
                                            :reduce="(option) => option.id" :options="search_machines"
                                            placeholder="Enter machines ..." v-model="search.machine_id"
                                            name="machine_id">
                                        </v-select>
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Search Site</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="site_name" :reduce="(option) => option.id"
                                            :options="search_sites" placeholder="Select Site..."
                                            v-model="search.site_id" name="site_id">
                                        </v-select>
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Category</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :reduce="(option) => option.id" :options="categories"
                                            placeholder="Choose Category ..." v-model="search.category_id"> </v-select>
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Sub Category</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :reduce="(option) => option.id" :options="sub_categories"
                                            placeholder="Choose description ..." v-model="search.sub_category_id">
                                        </v-select>
                                    </div>
                                </div>




                                <div class="row">
                                    <div class="col-6 mb-2 pr-1">
                                        <button type="submit" class="btn btn-success btn-block">Search</button>
                                    </div>
                                    <div class="col-6 mb-2 pl-1">
                                        <button type="button" class="btn btn-danger btn-block"
                                            @click="reset_filter()">Reset</button>
                                    </div>
                                    <div class="col-12 mb-2">
                                        <download-excel class="btn btn-warning btn-block" :fetch="export_csv"
                                            :fields="json_fields" :before-generate="startDownload"
                                            :before-finish="finishDownload" worksheet="My Worksheet" type="csv"
                                            name="site_expenses.csv"
                                            v-if="$gate.hasPermission('can_download_site_wise_expense_report')">
                                            <span class="labelText">
                                                <i class="fa fa-file-excel-o" aria-hidden="true"></i>
                                                Export as CSV</span>
                                        </download-excel>
                                    </div>
                                </div>
                            </form>
                        </SidebarModal>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0 ticketTable">
                            <table class="table table-hover table-striped" v-if="Tickets && Tickets.records">
                                <thead>
                                    <tr>
                                        <th class="stickey d-none">Action</th>
                                        <th>Site Name</th>
                                        <th>Site ID</th>
                                        <th>Actual Material Expenses </th>
                                        <th>Actual Service Expenses</th>
                                        <th>Total Expenses</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="ticket in Tickets.records.data" :key="ticket.id"
                                        :class="ticket.row_color">
                                        <td class="d-none"></td>
                                        <td class="pb-2">{{ ticket.site_name }}</td>
                                        <td>{{ ticket.site_id }}</td>
                                        <td>{{ ticket.material_expenses | toCurrency }}</td>
                                        <td>{{ ticket.service_expenses | toCurrency }}</td>
                                        <td>{{ (ticket.material_expenses + ticket.service_expenses) | toCurrency }}</td>

                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="table-dark">
                                        <!-- <td colspan="2"></td> -->
                                        <td colspan="2" class="pb-2">Total</td>
                                        <td><span v-if="Tickets && Tickets.actual_material_cost">{{
                                    Tickets.actual_material_cost | toCurrency }}</span></td>
                                        <td><span v-if="Tickets && Tickets.actual_service_cost">{{
                                    Tickets.actual_service_cost | toCurrency }}</span></td>
                                        <td>{{ (Tickets.actual_material_cost + Tickets.actual_service_cost) | toCurrency }}
                                        </td>

                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer" v-if="Tickets && Tickets.records">
                            <pagination :data="Tickets.records" @pagination-change-page="getResults"></pagination>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import { MonthPicker } from 'vue-month-picker'
import { MonthPickerInput } from 'vue-month-picker'
import SidebarModal from './../SideBarModal.vue';
export default {
    name: "SiteWiseExpenses",
    components: {
        MonthPicker,
        MonthPickerInput,
        SidebarModal
    },
    data() {
        return {
            pmModalData: "",
            total_service_cost: 0,
            total_material_cost: 0,
            created_users: [],
            search_machines: [],
            search_sites: [],
            search: {
                page: 1,
                machine_id: "",
                site_id: "",
                category_id: "",
                sub_category_id: "",
                monthYear: "",
                date_from: '',
                date_to: '',
                report_type: "site wise",
            },
            categories: [],
            sub_categories: [],
            sites: [],
            selected_machine: "",
            users: [],
            machines: [],
            Tickets: {},
            clearEmittedText: '',
            default_month: '',
            json_fields: {
                "Site Name": "site_name",
                "Site ID": "site_id",
                "Actual Material Expenses": "material_expenses",
                "Actual Service Expenses": "service_expenses",
                "Total Expenses": "total_expenses",
            },
            json_meta: [
                [
                    {
                        key: "charset",
                        value: "utf-8",
                    },
                ],
            ],
        };
    },
    methods: {
        openSideModal() {
            this.$refs.sidebarModal.openSideModal();
        },
        closeSideModal() {
            this.$refs.sidebarModal.closeSideModal();
        },
        showClearText() {
            this.clearEmittedText = 'emitted'
            this.default_month = ''
            window.setTimeout(() => {
                this.clearEmittedText = null
            }, 1000)
        },
        async get_machine() {
            axios.get("/api/reports/machines", {
                params: {
                    site_id: this.search.site_id,
                    category_id: this.search.category_id,
                    sub_category_id: this.search.sub_category_id,
                },
            })
                .then((response) => {
                    this.search_machines = response.data.data;
                })
                .catch(() => console.warn("Oh. Something went wrong"));
        },
        reset_filter() {
            this.search = {
                page: 1,
                machine_id: "",
                site_id: "",
                category_id: "",
                sub_category_id: "",
                monthYear: "",
                report_type: "site wise",
            };
            this.getResults();
        },
        UpdateValues(e) {
            this.search.tat_from = e.minValue;
            this.search.tat_to = e.maxValue;
        },
        // excel
        async export_csv() {
            this.search.report_type = 'site wise export'
            const response = await axios.post("api/reports", this.search);
            this.search.report_type = 'site wise'
            return response.data.data;
        },
        startDownload() {
            Swal.fire({
                title: "Please Wait !",
                html: "Data populating",
                allowOutsideClick: false,
                onBeforeOpen: () => {
                    Swal.showLoading();
                },
            });
        },
        finishDownload() {
            Swal.close();
        },

        getLabel(val) {
            if (typeof val === "object") {
                return val.far_no + " - " + val.name;
            } else {
                return val;
            }
        },
        getResults(page = 1) {
            let cloaderd = this.$loading.show();
            this.search.page = page;

            axios.post("/api/reports", this.search)
                .then(res => {
                    this.Tickets = res.data.data
                    cloaderd.hide();
                })
                .catch(err => {
                    console.error(err);
                    cloaderd.hide();
                })
        },

    },
    created() {
        this.getResults();
    },
    beforeCreate() {
        axios.get("api/get_pre_machine").then((res) => {
            this.categories = res.data.data.Category;
            this.sites = res.data.data.sites;
        });
        axios
            .get("/api/initial_ticket")
            .then((response) => {
                this.users = response.data.data.vendors;
                this.machines = response.data.data.machines;
                this.search_machines = response.data.data.machines;
                this.search_sites = response.data.data.sites;
                this.created_users = response.data.data.created_users;
            })
            .catch(() => console.warn("Oh. Something went wrong"));
    },
    watch: {
        async "search.sub_category_id"(n, o) {
            if (n) {
                this.get_machine();
            }
        },
        async "search.site_id"(n, o) {
            if (n) {
                this.get_machine();
            }
        },

        "search.category_id": {
            handler: function (n, o) {
                if (n) {
                    axios.get("api/category/" + n).then((res) => {
                        this.sub_categories = res.data.data;
                    });
                    this.get_machine();
                }
            },
            deep: true,
            initial: true,
        },
    },


};





</script>
