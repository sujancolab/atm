<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-12">

                    <div class="card" >
                        <div class="card-header">
                            <h3 class="card-title">Mileage Report</h3>
                            <div class="card-tools">
                                <button class="btn btn-sm btn-primary" @click="download"><i
                                    class="fa fa-download mr-2" aria-hidden="true"></i> Download Excel</button>
                                <button class="btn btn-sm btn-blue" @click="openSideModal"><i
                                    class="fa fa-sliders-h mr-2" aria-hidden="true"></i> Filter</button>
                            </div>
                        </div>

                        <SidebarModal ref="sidebarModal">
                            <!-- Content of the sidebar modal goes here -->
                            <h3><i class="fa fa-sliders-h mr-2" aria-hidden="true" style="font-size: 22px;"></i> Filter
                            </h3>
                            <hr>
                            <form autocomplete="off" @submit.prevent="getResults()">

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">FAR No</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :get-option-label="getLabel"
                                            :reduce="(option) => option.id" :options="search_machines"
                                            placeholder="Enter machines ..." v-model="search.machine_id"
                                            name="machine_id">
                                        </v-select>
                                    </div>
                                </div>

                                <!-- <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Select Site</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="site_name" :reduce="(option) => option.id"
                                            :options="search_sites" placeholder="Select Site..."
                                            v-model="search.site_id" name="site_id">
                                        </v-select>
                                    </div>
                                </div> -->

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Category</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :reduce="(option) => option.id" :options="categories"
                                            placeholder="Choose Category ..." v-model="search.category_id"> </v-select>
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">Sub Category</label>
                                    </div>
                                    <div class="col">
                                        <v-select label="name" :reduce="(option) => option.id" :options="sub_categories"
                                            placeholder="Choose description ..." v-model="search.sub_category_id">
                                        </v-select>
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">From Date</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.start_at" input-class="form-control" placeholder="Date" />
                                    </div>
                                </div>

                                <div class="row align-items-center mb-2">
                                    <div class="col-auto col-custom">
                                        <label for="machine_id">To Date</label>
                                    </div>
                                    <div class="col">
                                        <datetime value-zone="Asia/Kolkata" v-model="search.end_at" input-class="form-control" placeholder="Date" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6 mb-2 pr-1">
                                        <button type="submit" class="btn btn-success btn-block">Search</button>
                                    </div>
                                    <div class="col-6 mb-2 pl-1">
                                        <button type="button" class="btn btn-danger btn-block"
                                            @click="reset_filter()">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </SidebarModal>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0 ticketTable">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th class="stickey">FAR No</th>
                                        <th>Name</th>
                                        <th>Current Site</th>
                                        <th>Model</th>
                                        <th>Total Oil Consumption</th>
                                        <th>Standard Mileage (Kms/Ltr)</th>
                                        <th>Actual Mileage (Kms/Ltr)</th>
                                        <th>Last Mileage (Kms/Ltr)</th>
                                        <th>Range Mileage (Kms/Ltr)</th>
                                        <th>Standard Consumption (Ltrs/Hr)</th>
                                        <th>Actual Consumption (Ltrs/Hr)</th>
                                        <th>Last Consumption (Ltrs/Hr)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(d, index)  in MainData.data" :key="index">
                                        <td>{{ d.far_no }}</td>
                                        <td >{{ d.name }}</td>
                                        <td class="pb-2">{{ d.current_site?d.current_site.site_name:"" }}</td>
                                        <td >{{ d.machine_model.name }}</td>
                                        <td >{{ d.total_oil_consumtion }} / {{d.total_entries}} filling</td>
                                        <td >{{ d.standard_consumption_hr_per_ltr?d.standard_consumption_hr_per_ltr:0 }}</td>
                                        <td >{{ d.actual_milage }}</td>
                                        <td >{{ d.last_milage }}</td>
                                        <td >-</td>
                                        <td >{{ d.standard_consumption_km_per_ltr?d.standard_consumption_km_per_ltr:0}}</td>
                                        <td >{{ d.actual_consumption }}</td>
                                        <td ></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <pagination :data="MainData" :limit="10" @pagination-change-page="getResults" v-if="MainData"></pagination>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import MultiRangeSlider from "multi-range-slider-vue";
import "multi-range-slider-vue/MultiRangeSliderBlack.css";
import "multi-range-slider-vue/MultiRangeSliderBarOnly.css";
import SidebarModal from './../SideBarModal.vue';

import VueTagsInput from '@johmun/vue-tags-input';
export default {
    components: {
        VueTagsInput,
        MultiRangeSlider,SidebarModal,
        MachinePop: () => import('../MachineFarPop.vue'),
    },
    data() {
        return {
            pmModalData:'',
            created_users: [],
            search_machines: [],
            search_sites: [],
            search: {
                page: 1,
                machine_id: '',
                site_id: '',
                start_at: '',
                end_at: '',
                category_id: '',
                sub_category_id: ''
            },
            categories: [],
            sub_categories: [],
            sites: [],
            selected_machine: '',
            users: [],
            machines: [],
            MainData: {},

        }
    },
    methods: {
        download(){
            let cloaderd = this.$loading.show();
            this.search.page = "";
            this.search.export = "export";
            axios({
                url: '/api/get_hsd_data',
                method: 'GET',
                responseType: 'blob', // Important
                params: this.search
            }).then(response => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', 'hsd_readings.xlsx'); // Set the file name
                document.body.appendChild(link);
                link.click();
                cloaderd.hide();
            }).catch(error => {
                console.error("There was an error downloading the file:", error);
                cloaderd.hide();
            });
        },
        openSideModal() {
            this.$refs.sidebarModal.openSideModal();
        },
        closeSideModal() {
            this.$refs.sidebarModal.closeSideModal();
        },
        view_site_details(data) {
            this.pmModalData = data
            $('#MachineSiteModal2').modal('show');
        },
        reset_filter(){
            this.search= {
                page: 1,
                machine_id: '',
                site_id: '',
                start_at: '',
                end_at: '',
            }
            this.getResults()
        },
        UpdateValues(e) {
            this.search.tat_from = e.minValue;
            this.search.tat_to = e.maxValue;
        },


        getLabel(val) {
            if (typeof val === 'object') {
                return val.far_no + ' - ' + val.name;
            } else {
                return val;
            }
        },
        getResults(page = 1) {

            let cloaderd = this.$loading.show();
            axios.get('api/get_mileage_data', {
                params: {
                    page: page,
                    search:this.search
                }
            }).then(({ data }) => {
                this.MainData = data.data
                cloaderd.hide();
            });
        },
        loadData() {
            let cloaderd = this.$loading.show();
            axios.get("/api/get_mileage_data", {
                params: this.search
            }).then(({
                data
            }) => {
                this.MainData = data.data;
                cloaderd.hide();
            });
        },

    },
    created() {
        this.loadData();
    },
    beforeCreate() {
        axios.get("/api/initial_ticket").then(response => {
            this.users = response.data.data.vendors;
            this.machines = response.data.data.machines;
            this.search_machines = response.data.data.machines;
            this.search_sites = response.data.data.sites;
            this.created_users = response.data.data.created_users;
        }).catch(() => console.warn('Oh. Something went wrong'));

        axios.get("api/get_pre_machine")
            .then((res) => {
                this.categories = res.data.data.Category;
            })
    },
    watch: {
        async 'search.category_id'(n, o) {
            if (o)
                this.form.sub_category_id = ''
            if (n) {
                axios.get("api/category/" + n)
                    .then((res) => {
                        this.sub_categories = res.data.data;
                    })
            }
        },
        async 'search.machine_companies_id'(n, o) {
            if (o)
                this.form.machine_models_id = ''
            if (n) {
                axios.get("api/model/" + n)
                    .then((res) => {
                        this.models = res.data.data;
                    })
            }
        },
    },
}
</script>
<style>
.bg-red {
  background-color: #ef5563 !important;
}
.bg-green {
  background-color: #70ed70 !important;
}
.bg-yellow {
  background-color: #f1c84c !important;
}
</style>
