<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Country extends Model {
	use SoftDeletes;

	protected $fillable = [
		'id', 'name', 'status',
	];
	public function getNameAttribute($value) {
		return ucfirst($value);
	}
	public function states() {
		return $this->hasMany(State::class);
	}

	public function cities() {
		return $this->hasManyThrough(City::class, State::class);
	}
}
